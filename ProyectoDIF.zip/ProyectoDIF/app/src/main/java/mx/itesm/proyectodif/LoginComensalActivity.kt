package mx.itesm.proyectodif

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.navigation.fragment.findNavController
import mx.itesm.proyectodif.databinding.ActivityLoginComensalBinding


class LoginComensalActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginComensalBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginComensalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Escoder la barra superior
        supportActionBar?.hide()

        registrarEventos()
    }

    private fun registrarEventos() {
        binding.btnLoginC.setOnClickListener {
            menuInicial()
        }
        binding.btnResponsable.setOnClickListener {
            loginResponsable()
        }
    }

    private fun menuInicial() {
        // MainActivity
        val i = Intent(this, MainActivity::class.java)
        startActivity(i)
    }
    private fun loginResponsable() {
        // LoginResponsableActivity
        val i = Intent(this, LoginResponsableActivity::class.java)
        startActivity(i)
    }
}