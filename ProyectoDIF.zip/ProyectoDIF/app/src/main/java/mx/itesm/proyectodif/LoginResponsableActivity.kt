package mx.itesm.proyectodif

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import mx.itesm.proyectodif.databinding.ActivityLoginResponsableBinding

class LoginResponsableActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginResponsableBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginResponsableBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Escoder la barra superior
        supportActionBar?.hide()

        registrarEventos()

    }

    private fun registrarEventos() {
        binding.btnLoginR.setOnClickListener {
            menuInicial()
        }
        binding.btnComensal.setOnClickListener {
            loginComensal()
        }
    }

    private fun menuInicial() {
        // MenuResponsableActivity
        val i = Intent(this, MenuResponsableActivity::class.java)
        startActivity(i)
    }
    private fun loginComensal() {
        // LoginResponsableActivity
        val i = Intent(this, LoginComensalActivity::class.java)
        startActivity(i)
    }
}