package mx.itesm.proyectodif

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.Toast
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import mx.itesm.proyectodif.databinding.ActivityMenuResponsableBinding

class MenuResponsableActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMenuResponsableBinding

    private lateinit var appBarConfiguration: AppBarConfiguration


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_menu_responsable)
        binding = ActivityMenuResponsableBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //https://developer.android.com/guide/navigation/integrations/ui?hl=es-419
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        //binding = ActivityMenuResponsableBinding.inflate(layoutInflater)
        //setContentView(binding.root)

        //supportFragmentManager.beginTransaction().replace(R.id.nav_host_fragment,
        //    InicioResponsableFrag()
        //).commit()

        //registrarEventos()
        //replaceFragment(InicioResponsableFrag())

    }
    // RadioGroup
    fun onRadioButtonClicked(view: View) {
        if (view is RadioButton) {
            // Is the button now checked?
            val checked = view.isChecked

            // Check which radio button was clicked
            when (view.getId()) {
                R.id.btnMujer ->
                    if (checked) {
                        Toast.makeText(this, "Mujer", Toast.LENGTH_SHORT).show()
                    }
                R.id.btnHombre ->
                    if (checked) {
                        Toast.makeText(this, "Hombre", Toast.LENGTH_SHORT).show()

                    }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }

    private fun registrarEventos() {
        /*binding.btnAgregarQR.setOnClickListener {
            /*val menu = InicioResponsableFrag()
            val fragment : Fragment? =

            supportFragmentManager.findFragmentByTag(InicioResponsableFrag::class.java.simpleName)

            if (fragment !is InicioResponsableFrag){
                supportFragmentManager.beginTransaction()
                    .add(menu, InicioResponsableFrag::class.java.simpleName)
                    .commit()
            }*/
            replaceFragment(RegistrarRacionesFrag())

        }*/

    }
/*
    private fun replaceFragment(fragment: Fragment){
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment)
        fragmentTransaction.commit()
    }*/
}