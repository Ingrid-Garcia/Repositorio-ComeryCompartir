package mx.itesm.proyectodif.ui_comensal.model

import com.google.gson.annotations.SerializedName

data class Comedor(
    @SerializedName("Ubicacion")
    var ubicacion: String
)
