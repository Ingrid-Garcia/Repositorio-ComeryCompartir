package mx.itesm.proyectodif.ui_comensal.model

/**
 * @author Noh Ah Kim Kwon
 *
 */
data class Encuesta(
    var idCom: Int,
    var Calidad: Int,
    var Higiene: Int,
    var Servicio: Int,
    var Comentario: String
)

