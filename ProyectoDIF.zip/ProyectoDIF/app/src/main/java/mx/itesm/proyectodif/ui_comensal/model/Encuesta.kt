package mx.itesm.proyectodif.ui_comensal.model

data class Encuesta(
    var idCom: Int,
    var Calidad: Int,
    var Higiene: Int,
    var Servicio: Int,
    var Comentario: String
)

