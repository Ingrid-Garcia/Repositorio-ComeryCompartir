package mx.itesm.proyectodif.ui_comensal.model

import com.google.gson.annotations.SerializedName

data class LoginComensal(
    var id: Int,
    var pass: String
)
