package mx.itesm.proyectodif.ui_comensal.model

/**
 * @author Noh Ah Kim Kwon
 *
 */
data class LoginComensal(
    var id: Int,
    var pass: String
)
