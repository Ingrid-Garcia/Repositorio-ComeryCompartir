package mx.itesm.proyectodif.ui_comensal.model

data class RespuestaServidor(val mensaje: String)
