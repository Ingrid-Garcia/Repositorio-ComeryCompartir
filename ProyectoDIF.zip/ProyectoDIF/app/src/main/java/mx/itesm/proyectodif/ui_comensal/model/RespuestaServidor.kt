package mx.itesm.proyectodif.ui_comensal.model

/**
 * @author Noh Ah Kim Kwon
 *
 * Recibir repuesta del servidor
 */
data class RespuestaServidor(val mensaje: String)
