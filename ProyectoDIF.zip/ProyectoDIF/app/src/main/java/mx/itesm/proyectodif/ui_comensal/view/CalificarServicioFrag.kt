package mx.itesm.proyectodif.ui_comensal.view

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import mx.itesm.proyectodif.MainActivity
import mx.itesm.proyectodif.ui_comensal.viewmodel.CalificarServicioVM
import mx.itesm.proyectodif.R
// VISTA
/**
 * @author Noh Ah Kim Kwon
 *
 * Controla la vista del fragmento calificarServicio
 */
class CalificarServicioFrag : Fragment() {

    companion object {
        fun newInstance() = CalificarServicioFrag()
    }

    private lateinit var viewModel: CalificarServicioVM

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Esconder el menú de navegación
        (requireActivity() as MainActivity).setBottomNavigationVisibility(View.GONE)

        return inflater.inflate(R.layout.fragment_calificar_servicio, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(CalificarServicioVM::class.java)
        // TODO: Use the ViewModel
    }

    override fun onDestroy() {
        super.onDestroy()
        // Aparece el menú de navegación
        (requireActivity() as MainActivity).setBottomNavigationVisibility(View.VISIBLE)
    }

}