package mx.itesm.proyectodif.ui_comensal.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import mx.itesm.proyectodif.MainActivity
import mx.itesm.proyectodif.R
import mx.itesm.proyectodif.ui_comensal.viewmodel.CodigoQRVM


// VISTA
/**
 * @author Noh Ah Kim Kwon
 *
 * Controla la vista del fragmento codigoQR
 */
class CodigoQRFrag : Fragment() {

    /*companion object {
        fun newInstance() = CodigoQRFrag()
    }*/

    private lateinit var viewModel: CodigoQRVM

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Esconder el menú de navegación
        (requireActivity() as MainActivity).setBottomNavigationVisibility(View.GONE)

        return inflater.inflate(R.layout.fragment_codigo_q_r, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(CodigoQRVM::class.java)
        // TODO: Use the ViewModel
    }

    override fun onDestroy() {
        super.onDestroy()
        // Aparece el menú de navegación
        (requireActivity() as MainActivity).setBottomNavigationVisibility(View.VISIBLE)

    }

}