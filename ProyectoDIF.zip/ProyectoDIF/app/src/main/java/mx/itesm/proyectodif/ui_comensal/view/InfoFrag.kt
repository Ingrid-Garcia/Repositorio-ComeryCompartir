package mx.itesm.proyectodif.ui_comensal.view

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import mx.itesm.proyectodif.databinding.FragmentInformacionBinding
import mx.itesm.proyectodif.ui_comensal.viewmodel.InfoVM
// VISTA
/**
 * @author Noh Ah Kim Kwon
 *
 * Controla la vista del fragmento navegacion_info
 */
class InfoFrag : Fragment() {

    // View binding
    private lateinit var binding: FragmentInformacionBinding

    //private var _binding: FragmentInformacionBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    //private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val infoViewModel =
            ViewModelProvider(this).get(InfoVM::class.java)

        binding = FragmentInformacionBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //(requireActivity() as AppCompatActivity).supportActionBar?.hide()

        val textView: TextView = binding.textNotifications
        infoViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        registrarEventos()
    }

    private fun registrarEventos() {
        binding.btnPrivacidad.setOnClickListener {

        }
        binding.btnContacto.setOnClickListener {
            val accion = InfoFragDirections.actionNavegacionInfoToDatoContactoFrag2()
            findNavController().navigate(accion)
        }
        binding.btnCalificarServicio.setOnClickListener {
            val accion = InfoFragDirections.actionNavegacionInfoToCalificarServicioFrag()
            findNavController().navigate(accion)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        //_binding = null

        //(requireActivity() as AppCompatActivity).supportActionBar?.show()

    }
}