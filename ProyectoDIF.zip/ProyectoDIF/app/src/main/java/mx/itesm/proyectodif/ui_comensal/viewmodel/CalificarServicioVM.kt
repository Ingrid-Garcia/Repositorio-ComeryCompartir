package mx.itesm.proyectodif.ui_comensal.viewmodel

import androidx.lifecycle.ViewModel

class CalificarServicioVM : ViewModel() {
    // TODO: Implement the ViewModel
}