package mx.itesm.proyectodif.ui_comensal.viewmodel

import androidx.lifecycle.ViewModel

class CodigoQRVM : ViewModel() {
    // TODO: Implement the ViewModel
}