package mx.itesm.proyectodif.ui_comensal.viewmodel

import androidx.lifecycle.ViewModel

class LoginComensalVM : ViewModel() {
    // TODO: Implement the ViewModel
}