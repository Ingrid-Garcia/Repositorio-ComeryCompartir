package mx.itesm.proyectodif.ui_responsable.model

import com.google.gson.annotations.SerializedName

data class Comensal(
    @SerializedName("IDComensal")
    var id: Int,
    @SerializedName("Nombre")
    var nombre: String
)
