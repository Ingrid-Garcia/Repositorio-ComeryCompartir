package mx.itesm.proyectodif.ui_responsable.model

/**
 * @author Noh Ah Kim Kwon
 *
 * IncidenteAPI
 */
data class Incidente(
    var idRes: Int,
    var incidente: String
)
