package mx.itesm.proyectodif.ui_responsable.model

data class Incidente(
    var idRes: Int,
    var incidente: String
)
