package mx.itesm.proyectodif.ui_responsable.model

data class LoginResponsable(
    var id: Int,
    var pass: String
)
