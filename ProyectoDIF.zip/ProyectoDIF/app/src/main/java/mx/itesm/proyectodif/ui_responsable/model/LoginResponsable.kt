package mx.itesm.proyectodif.ui_responsable.model

/**
 * @author Noh Ah Kim Kwon
 *
 * LoginResponsableAPI
 */
data class LoginResponsable(
    var id: Int,
    var pass: String
)
