package mx.itesm.proyectodif.ui_responsable.model

data class RacionDon(
    var idCom: Int,
    var idComensal: Int
)
