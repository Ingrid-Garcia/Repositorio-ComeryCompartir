package mx.itesm.proyectodif.ui_responsable.model

/**
 * @author Noh Ah Kim Kwon
 *
 * RacionDonAPI
 */
data class RacionDon(
    var idCom: Int,
    var idComensal: Int
)
