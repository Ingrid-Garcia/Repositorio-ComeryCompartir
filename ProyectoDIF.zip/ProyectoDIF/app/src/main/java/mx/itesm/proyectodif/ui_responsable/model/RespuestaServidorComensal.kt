package mx.itesm.proyectodif.ui_responsable.model

data class RespuestaServidorComensal(
    val comensales: List<ComensalAPI>
)
