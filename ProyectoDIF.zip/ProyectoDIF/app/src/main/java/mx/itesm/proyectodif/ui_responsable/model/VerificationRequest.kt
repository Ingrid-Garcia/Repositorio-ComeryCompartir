package mx.itesm.proyectodif.ui_responsable.model

class VerificationRequest(scannedText: String?) {

}
