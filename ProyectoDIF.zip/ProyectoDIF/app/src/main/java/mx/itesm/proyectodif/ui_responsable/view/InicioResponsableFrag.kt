package mx.itesm.proyectodif.ui_responsable.view

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController

import mx.itesm.proyectodif.databinding.FragmentInicioResponsableBinding
import mx.itesm.proyectodif.ui_responsable.viewmodel.InicioResponsableVM

// VISTA
/**
 * @author Noh Ah Kim Kwon
 *
 * Controla la vista del fragmento inicioResponsable
 */
class InicioResponsableFrag : Fragment() {

    /*companion object {
        fun newInstance() = InicioResponsableFrag()
    }*/

    private lateinit var binding: FragmentInicioResponsableBinding

    private lateinit var viewModel: InicioResponsableVM

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentInicioResponsableBinding.inflate(layoutInflater)
        return binding.root

        //return inflater.inflate(R.layout.fragment_inicio_responsable, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(InicioResponsableVM::class.java)
        // TODO: Use the ViewModel
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        registrarEventos()
    }

    private fun registrarEventos() {
        binding.btnAgregarQR.setOnClickListener {
            Toast.makeText(context, "Escanear QR", Toast.LENGTH_SHORT).show()
        }
        binding.btnRaciones.setOnClickListener {
            val accion = InicioResponsableFragDirections.actionInicioResponsableFragToRegistrarRacionesFrag2()
            findNavController().navigate(accion)
        }
        binding.btnRacionesPara.setOnClickListener {
            val accion = InicioResponsableFragDirections.actionInicioResponsableFragToPedidoParaFrag()
            findNavController().navigate(accion)
        }
        binding.btnRacionDonada.setOnClickListener {
            val accion = InicioResponsableFragDirections.actionInicioResponsableFragToRacionDonadaFrag2()
            findNavController().navigate(accion)
        }
        binding.btnIncidencias.setOnClickListener {
            val accion = InicioResponsableFragDirections.actionInicioResponsableFragToRegistroIncidenciasFrag2()
            findNavController().navigate(accion)
        }
    }

}