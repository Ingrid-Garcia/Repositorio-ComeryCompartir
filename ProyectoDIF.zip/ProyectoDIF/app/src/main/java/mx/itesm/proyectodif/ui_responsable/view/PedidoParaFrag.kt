package mx.itesm.proyectodif.ui_responsable.view

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import mx.itesm.proyectodif.ui_responsable.viewmodel.PedidoParaVM
import mx.itesm.proyectodif.R
import mx.itesm.proyectodif.databinding.FragmentPedidoParaBinding
import mx.itesm.proyectodif.databinding.FragmentRacionDonadaBinding
import mx.itesm.proyectodif.databinding.FragmentRegistradoBinding

// VISTA
/**
 * @author Noh Ah Kim Kwon
 *
 * Controla la vista del fragmento PedidoPara
 */
class PedidoParaFrag : Fragment() {

    /*companion object {
        fun newInstance() = PedidoParaFrag()
    }*/

    private lateinit var binding: FragmentPedidoParaBinding

    private lateinit var viewModel: PedidoParaVM

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //return inflater.inflate(R.layout.fragment_pedido_para, container, false)
        binding = FragmentPedidoParaBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(PedidoParaVM::class.java)
        // TODO: Use the ViewModel
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        registrarEventos()
    }

    private fun registrarEventos() {
        binding.btnRegistrarPara.setOnClickListener {
            val accion = PedidoParaFragDirections.actionPedidoParaFragToRegistradoFrag()
            findNavController().navigate(accion)
        }
    }
}