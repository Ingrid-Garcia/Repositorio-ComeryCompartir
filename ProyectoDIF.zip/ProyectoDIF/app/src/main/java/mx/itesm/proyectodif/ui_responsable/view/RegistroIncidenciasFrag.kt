package mx.itesm.proyectodif.ui_responsable.view

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import mx.itesm.proyectodif.databinding.FragmentRegistroIncidenciasBinding
import mx.itesm.proyectodif.ui_responsable.viewmodel.RegistroIncidenciasVM

// VISTA
/**
 * @author Noh Ah Kim Kwon
 *
 * Controla la vista del fragmento registroIncidencias
 */
class RegistroIncidenciasFrag : Fragment() {

    /*companion object {
        fun newInstance() = RegistroIncidenciasFrag()
    }*/
    private lateinit var binding: FragmentRegistroIncidenciasBinding

    private lateinit var viewModel: RegistroIncidenciasVM

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRegistroIncidenciasBinding.inflate(layoutInflater)
        return binding.root
        //return inflater.inflate(R.layout.fragment_registro_incidencias, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(RegistroIncidenciasVM::class.java)
        // TODO: Use the ViewModel
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        registrarEventos()
    }

    private fun registrarEventos() {
        binding.btnEnviar.setOnClickListener {
            val accion = RegistroIncidenciasFragDirections.actionRegistroIncidenciasFrag2ToRegistradoFrag()
            findNavController().navigate(accion)
        }
    }

}