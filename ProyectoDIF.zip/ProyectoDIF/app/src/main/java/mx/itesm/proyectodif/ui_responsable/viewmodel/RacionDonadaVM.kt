package mx.itesm.proyectodif.ui_responsable.viewmodel

import androidx.lifecycle.ViewModel

class RacionDonadaVM : ViewModel() {
    // TODO: Implement the ViewModel
}