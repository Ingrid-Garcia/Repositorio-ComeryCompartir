package mx.itesm.proyectodif.ui_responsable.viewmodel

import androidx.lifecycle.ViewModel

class RegistroIncidenciasVM : ViewModel() {
    // TODO: Implement the ViewModel
}