package mx.itesm.proyectodif.ui_responsable.viewmodel

import androidx.lifecycle.ViewModel

class RegistroRacionesConQRVM : ViewModel() {
    // TODO: Implement the ViewModel
}